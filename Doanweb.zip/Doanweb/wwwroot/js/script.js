﻿const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();

            alert(data.message || data.Message || "Đăng nhập thành công!");

            if (data.success || data.Success) {
                localStorage.setItem('omego_user', data.username || data.Username);
                
            }
        } catch (error) {
            console.error('Lỗi đăng nhập:', error);
            alert('Không thể kết nối đến máy chủ!');
        }
    });
}