﻿namespace Doanweb.Models
{
    public class Topic // Đảm bảo tên class khớp với khai báo trong AppDbContext
    {
        public int Id { get; set; }
        public string? TopicCode { get; set; }
        public string? TopicName { get; set; }
        public string? Description { get; set; }
        public string? Icon { get; set; }
    }
}