﻿using Microsoft.AspNetCore.Mvc;
using Doanweb.Models;
using System.Linq;

namespace Doanweb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _context;
        public AuthController(AppDbContext context) { _context = context; }

        [HttpPost("register")]
        public IActionResult Register([FromBody] User user)
        {
            if (_context.Users.Any(u => u.Username == user.Username))
                return BadRequest(new { success = false, message = "Tên đăng nhập đã tồn tại!" });

            _context.Users.Add(user);
            _context.SaveChanges();
            return Ok(new { success = true, message = "Đăng ký thành công!" });
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] User user)
        {
            var existingUser = _context.Users.FirstOrDefault(u => u.Username == user.Username && u.Password == user.Password);
            if (existingUser == null)
                return BadRequest(new { success = false, message = "Sai tên đăng nhập hoặc mật khẩu!" });

            return Ok(new { success = true, message = "Đăng nhập thành công!", username = existingUser.Username });
        }
    }
}