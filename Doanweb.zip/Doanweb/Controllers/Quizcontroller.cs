﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Doanweb.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Doanweb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuizController : ControllerBase
    {
        private readonly AppDbContext _context;

        public QuizController(AppDbContext context)
        {
            _context = context;
        }

        // 1. API lấy danh sách toàn bộ chủ đề từ bảng Topics (Route: /api/quiz/topics)
        [HttpGet("topics")]
        public IActionResult GetAllTopics()
        {
            var topics = _context.Topics
                .AsNoTracking()
                .ToList();

            return Ok(topics);
        }

        // 2. API lấy danh sách câu hỏi theo chủ đề (Route: /api/quiz/topic/{topic})
        [HttpGet("topic/{topic}")]
        public IActionResult GetQuestionsByTopic(string topic)
        {
            if (string.IsNullOrEmpty(topic))
            {
                return BadRequest(new { message = "Chủ đề không hợp lệ!" });
            }

            var questions = _context.Questions
                .AsNoTracking()
                .Where(q => q.Topic != null && q.Topic.ToLower() == topic.ToLower())
                .Select(q => new
                {
                    q.Id,
                    q.Topic,
                    q.QuestionText,
                    q.OptionA,
                    q.OptionB,
                    q.OptionC,
                    q.OptionD
                })
                .ToList();

            return Ok(questions);
        }

        // 3. API Nộp bài (Route: /api/quiz/submit)
        [HttpPost("submit")]
        public IActionResult SubmitQuiz([FromBody] SubmitRequest request)
        {
            if (request?.Answers == null || !request.Answers.Any())
            {
                return BadRequest(new { message = "Chưa có đáp án nào được gửi!" });
            }

            int score = 0;
            int total = request.Answers.Count;

            var questionIds = request.Answers.Keys.ToList();
            var dbQuestions = _context.Questions
                .AsNoTracking()
                .Where(q => questionIds.Contains(q.Id))
                .ToDictionary(q => q.Id, q => q.CorrectAnswer);

            foreach (var userAns in request.Answers)
            {
                if (dbQuestions.TryGetValue(userAns.Key, out string correctAns) && !string.IsNullOrEmpty(correctAns))
                {
                    if (string.Equals(correctAns.Trim(), userAns.Value?.Trim(), StringComparison.OrdinalIgnoreCase))
                    {
                        score++;
                    }
                }
            }

            return Ok(new
            {
                success = true,
                score = score,
                total = total,
                message = $"Bạn đã làm đúng {score}/{total} câu!"
            });
        }
    }

    public class SubmitRequest
    {
        public Dictionary<int, string>? Answers { get; set; }
    }
}